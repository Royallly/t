package com.sutest512.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class HelloController {

    @GetMapping("/isSpringStarted")
    public String hello() {
        return "Started";
    }

}
